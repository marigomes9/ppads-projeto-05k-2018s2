README

	Ambiente Admin Catálogo

Requisitos:

Git
Mongodb
NodeJS 6.10.3

Procedimentos:

Clone o repositório

Após selecionar a pasta onde ficar�o os fonts, abra o terminal, navegue at� a pasta e instale as seguintes depend�ncias:

npm install -g webpack
npm install -g nodemon

npm install

npm run dev


 Fazer o deploy

- acessar o servidor
- entrar na pasta do projeto
- depois é só executar o ./deploy.sh