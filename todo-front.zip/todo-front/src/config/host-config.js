'use strict'

var serviceUrl

serviceUrl = 'https://mackjob-back.azurewebsites.net/api/'

if (DEBUG) {
    serviceUrl = 'http://localhost:3000/api/'
}

module.exports = {
    serviceUrl: serviceUrl
}