﻿angular.module('mask', [])
.directive('format', ['$filter', '$location', '$locale', function ($filter, $location, $locale) {
    window.$locale = $locale;
    return {
        require: '?ngModel',
        link: function (scope, elem, attrs, ctrl) {
            if (!ctrl) return;

            function phone(v) {
                v = v.replace(/\D/g, "");
                if (v.length === 1) {
                    v = "(" + v;
                }
                else {
                    v = v.replace(/^(\d\d)/g, "($1)");
                    if (v.length > 12) {
                        v = v.replace(/(\d{5})(\d)/, "$1-$2");
                    }
                    else {
                        v = v.replace(/(\d{4})(\d)/, "$1-$2");
                    }
                }
                return v;
            };

            function zipCode(v) {
                v = v.replace(/\D/g, "")
                v = v.replace(/^(\d{5})(\d)/, "$1-$2")
                return v;
            };

            function mdata(v) {
                v = v.replace(/\D/g, "");                    //Remove tudo o que não é dígito
                v = v.replace(/(\d{2})(\d)/, "$1/$2");
                v = v.replace(/(\d{2})(\d)/, "$1/$2");

                v = v.replace(/(\d{2})(\d{2})$/, "$1$2");
                return v;
            }

            function data(v) {
                v = v.toString();
                v = v.replace(/\D/g, "");
                if (v.length == 2) {
                    v = v > 31 ? v = '31' : v;
                    v = v[0] + v[1] + '/';
                } else if (v.length == 3) {
                    v = v[0] + v[1] + '/' + v[2];
                    if (v[3] > 1)
                        v = v[0] + v[1] + '/' + '0' + v[3];
                } else if (v.length == 4) {
                    v = v[0] + v[1] + '/' + v[2] + v[3] + '/';
                    var month = v[3] + v[4];
                    if (month > 12)
                        v = v[0] + v[1] + v[2] + '1' + '2' + '/';
                } else if (v.length == 5)
                    v = v[0] + v[1] + '/' + v[2] + v[3] + '/' + v[4];
                else if (v.length == 6)
                    v = v[0] + v[1] + '/' + v[2] + v[3] + '/' + v[4] + v[5];
                else if (v.length == 7)
                    v = v[0] + v[1] + '/' + v[2] + v[3] + '/' + v[4] + v[5] + v[6];
                else if (v.length == 8) {
                    v = v[0] + v[1] + '/' + v[2] + v[3] + '/' + v[4] + v[5] + v[6] + v[7];
                    var year = +v[6] + v[7] + v[8] + v[9];
                    if (Number(year) < 1915 || Number(year) > 2100) {
                        v = v[0] + v[1] + '/' + v[3] + v[4] + '/' + '2' + '0' + '1' + '5';
                    }
                } else if (v.length > 8)
                    v = v[0] + v[1] + '/' + v[2] + v[3] + '/' + v[4] + v[5] + v[6] + v[7];
                return v;
            }

            function time(v) {
                var value = v.replace(/\D/g, "");
                if (value.length >= 5) {
                    value = value[0] + value[1] + value[2] + value[3];
                    value = value.replace(/(\d{2})(\d)/, "$1:$2");
                    return value;
                }
                if (value.length == 1)
                    value = value > 2 ? '0' + value : value;
                else if (value.length == 2)
                    value = value > 23 ? 23 : value;
                else if (value.length == 3)
                    value = value[2] > 5 ? '' + value[0] + value[1] + '5' : value;

                value = value.toString().replace(/(\d{2})(\d)/, "$1:$2");
                return value;
            };

            function currencyFull(v) {
                if (!v)
                    return;
                v = v;
                v = v.toString();
                v = v.replace(/\D/g, "");

                if (v.length == 3)
                    v = v[0] + ',' + v[1] + v[2];
                else if (v.length == 4)
                    v = v[0] + v[1] + ',' + v[2] + v[3];
                else if (v.length == 5)
                    v = v[0] + v[1] + ',' + v[2] + v[3] + v[4];
                else if (v.length == 6)
                    v = v[0] + v[1] + ',' + v[2] + v[3] + v[4] + v[5];
                else if (v.length == 7)
                    v = v[0] + v[1] + v[2] + ',' + v[3] + v[4] + v[5] + v[6];
                else if (v.length > 7)
                    v = v[0] + v[1] + v[2] + ',' + v[3] + v[4] + v[5] + v[6];
                //else if (v.length == 2) {
                   // v = v[0] + v[1] + ',' + '0' + '0' + '0' + '0';
                    //v = v.replace(/(\d)(\d{7})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                    //v = v.replace(/(\d)(\d{4})$/, "$1" + $locale.NUMBER_FORMATS.DECIMAL_SEP + "$2");
                //}
                //else if (v.length == 1) {
                  //  v = v[0] + ',' + '0' + '0' + '0' + '0';
                    //v = v.replace(/(\d)(\d{7})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                    //v = v.replace(/(\d)(\d{4})$/, "$1" + $locale.NUMBER_FORMATS.DECIMAL_SEP + "$2");
               // }
                v = v.replace(/(\d)(\d{13})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                v = v.replace(/(\d)(\d{10})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                v = v.replace(/(\d)(\d{7})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                v = v.replace(/(\d)(\d{4})$/, "$1" + $locale.NUMBER_FORMATS.DECIMAL_SEP + "$2");
                return v;
            }

            function currency(v) {
                if (!v)
                    return;
                v = v.toString();
                v = v.replace(/\D/g, "");
                v = v.replace(/(\d)(\d{11})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                v = v.replace(/(\d)(\d{8})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                v = v.replace(/(\d)(\d{5})$/, "$1" + $locale.NUMBER_FORMATS.GROUP_SEP + "$2");
                v = v.replace(/(\d)(\d{2})$/, "$1" + $locale.NUMBER_FORMATS.DECIMAL_SEP + "$2");
                return v;
            }


            function cpf(v) {
                v = v.replace(/\D/g, "");
                v = v.replace(/(\d{3})(\d)/, "$1.$2");
                v = v.replace(/(\d{3})(\d)/, "$1.$2");
                v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
                return v;
            }

            function cnpj(v) {
                v = v.replace(/\D/g, "");
                v = v.replace(/^(\d{2})(\d)/, "$1.$2");
                v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");
                v = v.replace(/\.(\d{3})(\d)/, ".$1/$2");
                v = v.replace(/(\d{4})(\d)/, "$1-$2");
                return v;
            }

            //to view
            ctrl.$formatters.unshift(function (value) {
                switch (attrs.format) {
                    case 'time':
                        return $filter('date')(value, 'HH:mm');
                    case 'currency':
                        return $filter('currency')(value, '', 4);
                        //case 'currencyFull':
                        //    return currencyFull(value);
                    case 'mdata':
                        return $filter('date')(value, 'dd/mm/YYYY');
                    case 'data':
                        {
                            if (value) {
                                var date = value;
                                if (typeof (date) != "string")
                                    date = date.toLocaleDateString();
                                date = date.split("-");
                                if (date.length > 1)
                                    date = date[2][0] + date[2][1] + '/' + date[1] + '/' + date[0];
                                return date;
                            }
                        }
                }
                return value;
            });

            function onlyLetters(v) {
                v = v.replace(/[^\w\s]/gi, "");

                return v;
            }

            function toModel(value) {
                switch (attrs.format) {
                    case 'number':
                        value = value.replace(/\D/g, "");
                        elem.val(value);
                        return value;
                    case 'phone':
                        value = phone(value);
                        elem.val(value);
                        return value;
                    case 'zipCode':
                        value = zipCode(value);
                        elem.val(value);
                        return value;
                    case 'cpf':
                        value = cpf(value);
                        elem.val(value);
                        return value;
                    case 'mdata':
                        value = mdata(value);
                        elem.val(value);
                        return value;
                    case 'data':
                        value = data(value);
                        elem.val(value);
                        return value;
                    case 'currencyFull':
                        value = currencyFull(value);
                        elem.val(value);
                        return value;
                    case 'onlyLetters':
                        value = onlyLetters(value);
                        elem.val(value);
                        return value;
                    case 'cnpj':
                        value = cnpj(value);
                        elem.val(value);
                        return value;
                    case 'time':
                        value = time(value);
                        elem.val(value);

                        if (({}).toString.call(ctrl.$modelValue).match(/\s([a-zA-Z]+)/)[1].toLowerCase() == 'date') {
                            ctrl.$modelValue.setHours(value.split(':')[0] || 0);
                            ctrl.$modelValue.setMinutes(value.split(':')[1] || 0);
                            ctrl.$modelValue.setSeconds(value.split(':')[2] || 0);
                            ctrl.$modelValue.setMilliseconds(value.split('.')[3] || 0);
                            return ctrl.$modelValue;
                        } else if (value.length == 5) {
                            //var hour = value.split(':')[0] || 0;
                            //var minutes = value.split(':')[1] || 0;
                            var date = moment("1/Jan/2015 " + value).tz("America/Sao_Paulo").format("HH:mm");
                            return date;
                        } else
                            return undefined;
                    case 'currency':
                        if (!value || value == '')
                            return;
                        value = currency(value);
                        elem.val(value);
                        while (value.indexOf($locale.NUMBER_FORMATS.GROUP_SEP) != -1)
                            value = value.replace($locale.NUMBER_FORMATS.GROUP_SEP, "");
                        value = value.replace($locale.NUMBER_FORMATS.DECIMAL_SEP, ".");
                        return parseFloat(value);
                }
            }
            ctrl.$parsers.unshift(toModel);
        }
    };
}]);
