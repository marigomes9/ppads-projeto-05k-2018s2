'use strict'

module.exports = function () {
  require('./utils/sweet-alert')
  require('./user/userService')
}
