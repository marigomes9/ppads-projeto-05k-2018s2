'use strict'

var appModule = require('../../appModule')

appModule.service('userService', UserService)

function UserService($http, Configuration, $localStorage) {
    this.urlBase = Configuration.serviceUrl
    this.$http = $http
    this.$localStorage = $localStorage
}

UserService.prototype.signin = function (user) {
  var that = this

  return this.$http({
      method: 'POST',
      url: that.urlBase + 'user/signin',
      data: user
  })
}

UserService.prototype.signup = function (user) {
  var that = this

  return this.$http({
      method: 'POST',
      url: that.urlBase + 'user/signup',
      data: user
  })
}

UserService.prototype.getFolders = function () {
  var that = this

  return this.$http({
      method: 'GET',
      url: that.urlBase + 'list/user/' + (JSON.parse(localStorage.getItem('user')))._id
  })
}

UserService.prototype.getFolder = function (id) {
  var that = this

  return this.$http({
      method: 'GET',
      url: that.urlBase + 'list/' + id
  })
}

UserService.prototype.getTasks = function (id) {
  var that = this

  return this.$http({
      method: 'GET',
      url: that.urlBase + 'task/list/' + id
  })
}

UserService.prototype.createList = function (name) {
  var that = this

  return this.$http({
      method: 'POST',
      url: that.urlBase + 'list',
      data: {
        'owner': (JSON.parse(localStorage.getItem('user')))._id,
        'title': name
      }
  })
}

UserService.prototype.createTask = function (task) {
  var that = this

  return this.$http({
      method: 'POST',
      url: that.urlBase + 'task',
      data: task
  })
}