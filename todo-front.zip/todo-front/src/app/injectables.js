module.exports = function () {

  require('./directives/index')();
  require('./services/index')();
  require('./modules/index')();
};
