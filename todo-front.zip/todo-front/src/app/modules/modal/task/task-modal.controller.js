'use strict'

var appModule = require('../../../appModule')

TaskModalController.$inject = ['$window', '$uibModalInstance', 'userService', '$stateParams']

function TaskModalController($window, $uibModalInstance, userService, $stateParams) {
  this.$window = $window
  this.$uibModalInstance = $uibModalInstance
  this.userService = userService
  this.$stateParams = $stateParams
}

TaskModalController.prototype.save = function () {
  var that = this
  var minutes = 0
  var seconds = 0

  if (!this.task.description) { return this.notifyUser({ title: 'Erro', text: 'A tarefa precisa de descrição'})}

  if (this.hasTime) {
    minutes += parseInt(this.duration.minutes) || 0
    minutes += parseInt(this.duration.hours) * 60 || 0
    this.task.time = minutes * 60
  }

  this.task.list = this.$stateParams.id


  this.userService.createTask(this.task)
    .then(function (res) {
      return that.$window.location.reload()
    })
    .catch(function (err) {
      return that.notifyUser({
        title: 'Erro',
        text: 'Lista não criada'
      })
    })
   .finally(function(){
     that.closeModal()
   })
}

TaskModalController.prototype.closeModal = function () {
  this.$uibModalInstance.dismiss('cancel')
}

TaskModalController.prototype.notifyUser = function (content) {
  swal({
    title: content.title,
    text: content.text,
    timer: 2000,
    showConfirmButton: false
  })
}

appModule.controller('taskModalController', TaskModalController)
