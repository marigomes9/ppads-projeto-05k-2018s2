'use strict'

var appModule = require('../../../appModule')

ListModalController.$inject = ['$window', '$uibModalInstance', 'userService']

function ListModalController($window, $uibModalInstance, userService) {
  this.$window = $window
  this.$uibModalInstance = $uibModalInstance
  this.userService = userService
}

ListModalController.prototype.save = function () {
  var that = this

  this.userService.createList(this.name)
    .then(function (res) {
      return that.$window.location.reload()
    })
    .catch(function (err) {
      return that.notifyUser({
        title: 'Erro',
        text: 'Lista não criada'
      })
    })
   .finally(function(){
     that.closeModal()
   })
}

ListModalController.prototype.closeModal = function () {
  this.$uibModalInstance.dismiss('cancel')
}

ListModalController.prototype.notifyUser = function (content) {
  swal({
    title: content.title,
    text: content.text,
    timer: 2000,
    showConfirmButton: false
  })
}

appModule.controller('listModalController', ListModalController)
