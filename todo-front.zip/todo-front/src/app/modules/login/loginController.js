'use strict'

var appModule = require('../../appModule')

LoginController.$inject = ['$location', 'userService']

function LoginController($location, userService) {
    this.$location = $location
    this.userService = userService

    this.user = {}

    this.initialize()
}

LoginController.prototype.initialize = function () {
  if (localStorage.getItem('isLogged')) {
    return this.$location.path('/listas')
  }
}

LoginController.prototype.login = function () {
  var that = this

  this.userService.signin(this.user)
    .then(function(res){
      localStorage.setItem('isLogged', true)
      localStorage.setItem('user', JSON.stringify(res.data))
      return that.$location.path('/listas')
    })
    .catch(function(err){
      return that.notifyUser({
        title: 'Erro',
        text: err.data.message
      })
    })
}

LoginController.prototype.notifyUser = function (content) {
  swal({
      title: content.title,
      text: content.text,
      timer: 2000,
      showConfirmButton: false
  })
}

appModule.controller('loginController', LoginController)
