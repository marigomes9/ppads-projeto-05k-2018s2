var appModule           = require('../../appModule');
var config              = require('../../../config/host-config');

appModule.constant('Configuration', {
  serviceUrl: config.serviceUrl
})