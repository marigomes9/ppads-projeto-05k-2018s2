var
  appModule = require('../../appModule'),
  viewLogin = require('../../modules/login/login.html'),
  viewSignup = require('../../modules/signup/signup.html'),
  viewList = require('../../modules/list/list.html')

appModule.config(RouteConfig);

RouteConfig.$inject = ['$stateProvider', '$urlRouterProvider'];

function RouteConfig($stateProvider, $urlRouterProvider) {

  $stateProvider.state('login', {
    url: "/login",
    templateUrl: viewLogin,
    data: {
      pageTitle: 'Login',
    },
    controller: 'loginController',
    controllerAs: 'vm'
  })

  $stateProvider.state('signup', {
    url: "/cadastro",
    templateUrl: viewSignup,
    data: {
      pageTitle: 'Cadastro',
    },
    controller: 'signupController',
    controllerAs: 'vm'
  })

  $stateProvider.state('list', {
    url: "/listas",
    templateUrl: viewList,
    data: {
      pageTitle: 'Listas',
    },
    controller: 'listController',
    controllerAs: 'vm'
  })

  $stateProvider.state('list_detail', {
    url: "/lista/:id",
    templateUrl: viewList,
    data: {
      pageTitle: 'Detalhe lista',
    },
    controller: 'listController',
    controllerAs: 'vm'
  })
}
