'use strict'

var appModule = require('../../appModule')

SignupController.$inject = ['$location', 'userService']

function SignupController($location, userService) {
    this.$location = $location
    this.userService = userService

    this.user = {}
}

SignupController.prototype.signup = function () {
  if (!this.user.email) { return this.notifyUser({ title: 'Erro', text: 'Insira um e-mail'})}
  if (!this.user.password) { return this.notifyUser({ title: 'Erro', text: 'Insira uma senha'})}
  if (!this.user.password2) { return this.notifyUser({ title: 'Erro', text: 'Confirme a senha'})}
  if (this.user.password !== this.user.password2) { return this.notifyUser({ title: 'Erro', text: 'Senhas diferentes'})}

  var that = this

  this.userService.signup(this.user)
    .then(function(res){
      localStorage.setItem('isLogged', true)
      localStorage.setItem('user', JSON.stringify(res.data))
      return that.$location.path('/listas')
    })
    .catch(function(err){
      return that.notifyUser({
        title: 'Erro',
        text: err.data.message
      })
    })
}

SignupController.prototype.notifyUser = function (content) {
  swal({
      title: content.title,
      text: content.text,
      timer: 2000,
      showConfirmButton: false
  })
}

appModule.controller('signupController', SignupController)
