'use strict'

module.exports = function () {
    require('./config/config')
    require('./config/routeConfig')
    require('./component/qsUtil')

    // login
    require('./login/loginController')

    // signup
    require('./signup/signup-controller')

    // list
    require('./list/list-controller')
    require('./modal/list/list-modal.controller')

    // task
    require('./modal/task/task-modal.controller')
}