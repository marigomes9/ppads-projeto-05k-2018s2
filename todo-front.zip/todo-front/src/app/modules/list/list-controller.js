'use strict'

var appModule = require('../../appModule')
var modal = require('../modal/list/list-modal.html')
var modalTask = require('../modal/task/task-modal.html')

ListController.$inject = ['$location', '$uibModal', 'userService', '$stateParams']

function ListController($location, $uibModal, userService, $stateParams) {
  this.$location = $location
  this.$uibModal = $uibModal
  this.userService = userService
  this.$stateParams = $stateParams

  this.initialize()
  this.listFolders()
}

ListController.prototype.initialize = function () {
  if (this.$stateParams.id) {
    this.isDetail = true
    this.title = '<h1 class="text-center"><small>Tarefas da </small><strong>LISTA</strong></h1>'
    return this.listTasks(this.$stateParams.id)
}

  this.title = '<h1 class="text-center"><small>Listas de </small><strong>TAREFAS</strong></h1>'
}

ListController.prototype.goToList = function (list) {
  return this.$location.path('/lista/' + list._id)
}

ListController.prototype.createList = function () {
  this.$uibModal.open({
    templateUrl: modal,
    controller: "listModalController as vm",
    resolve: {}
  })
}

ListController.prototype.createTask = function () {
  this.$uibModal.open({
    templateUrl: modalTask,
    controller: "taskModalController as vm",
    resolve: {}
  })
}

ListController.prototype.listFolders = function () {
  var that = this

  this.userService.getFolders()
    .then(function (res) {
      that.lists = res.data
    })
    .catch(function (err) {
      return that.notifyUser({
        title: 'Erro',
        text: 'Sem conexão'
      })
    })
}

ListController.prototype.listTasks = function (folder) {
  var that = this

  this.userService.getTasks(folder)
    .then(function (res) {
      that.tasks = res.data
      that.tasks.map(function(task){
        if (!task.time) {
          task.time = '--'
        }

        if (task.time) {
          task.time = moment().startOf('day')
          .seconds(task.time)
          .format('HH:mm:ss')
        }
      })
    })
    .catch(function (err) {
      return that.notifyUser({
        title: 'Erro',
        text: 'Sem conexão'
      })
    })
}

ListController.prototype.notifyUser = function (content) {
  swal({
      title: content.title,
      text: content.text,
      timer: 2000,
      showConfirmButton: false
  })
}

appModule.controller('listController', ListController)
