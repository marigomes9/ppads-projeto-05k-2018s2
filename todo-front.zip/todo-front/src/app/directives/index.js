module.exports = function () {

  require('./directives');

};
