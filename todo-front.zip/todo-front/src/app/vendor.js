module.exports = function() {
    /* Styles */
    require("./scss/style.scss");

    /* JS */
    require('angular');
    require('angular-ui-router');
    require('angular-ui-bootstrap');
    require('bootstrap');
    require('metismenu');
    require('ngstorage');
    require('ng-lodash');
    require('ng-draggable');
    require('angular-xeditable/dist/js/xeditable.min');
    require('angular-xeditable')
    require('checklist-model');
    require('angular-route');
    require('ui-select');
    require('angular-input-masks');
    require('angular-sanitize');
    require('angular-filter');
    require('angular-cookies');
    require('angular-loading-bar');
    require('ng-infinite-scroll');
    require('moment');
    require('moment/locale/pt-br');
    require('humanize-duration');
    require('angular-ui-mask');
    require('angular-input-masks');
    require('sweetalert');
    require('lodash');
    require('angular-feature-flags/dist/featureFlags.min');


    //drag
    require('angular-ui-sortable');

    //wizard
    require('ng-dialog');
    require('angular-wizard');


    // require('eonasdan-bootstrap-datetimepicker');

    //tour
    require('angular-hotkeys');
    require('ngSmoothScroll');
    require('ez-ng');

    require('angular-ui-tour');

    //Bibliotecas inexistentes no NPM
    require('./customLibs/angular-tags-0.2.10-tpls');
    require('./customLibs/angular-bootstrap-multiselect.min');

    //Bibliotecas incompativeis com o webpack mexidas para funcionar com o mesmo
    require('./customLibs/angular-title');
    require('./customLibs/icheck');
    require('./customLibs/angular-chrono');
    require('./customLibs/angular-moment');
    require('./customLibs/angular-notify');
    require('./customLibs/png-time-input');
    require('./customLibs/angucomplete-alt');
    require('./customLibs/angular-google-analytics');
    require('./customLibs/customPopover');
    require('./customLibs/mask');
    require('./customLibs/angular-locale_pt-br');

};