#!/bin/bash

# exclusão do container
docker rm -f todo_front

# exclusão da imagen
docker rmi -f todo/todo_front

# criação da imagem
docker build -f Dockerfile -t todo/todo_front .

# criação do container do front e execução
docker run --restart=always -d -p 80:80 \
        -e NODE_ENV=production \
        --name todo_front todo/todo_front

